$(document).ready(function() {
    
    $("#button1").click(function() {
            $(".steps").hide();
            $("#content1").slideDown("slow");
    });

    $("#button2").click(function() {
            $(".steps").hide();
            $("#content2").slideDown("slow");              
    });
    
    $("#button3").click(function() {
            $(".steps").hide();
            $("#content3").slideDown("slow");              
    });
    
    $("#button4").click(function() {
            $(".steps").hide();
            $("#content4").slideDown("slow");              
    });
    
    $("#button5").click(function() {
            $(".steps").hide();
            $("#content5").slideDown("slow");              
    });
    
        $("#forward").click(function(){
                var nextDiv = $(".steps:visible").next(".steps");
                if (nextDiv.length === 0){
                    nextDiv = $(".steps:first");
                }
                $(".steps").hide();
                nextDiv.fadeIn(800);
        });
    
        $("#previous").click(function(){
            var prevDiv = $(".steps:visible").prev(".steps");
            if (prevDiv.length === 0){
                prevDiv = $(".steps:last");
            }
            $(".steps").hide();
            prevDiv.show("slow");
    });
  
});